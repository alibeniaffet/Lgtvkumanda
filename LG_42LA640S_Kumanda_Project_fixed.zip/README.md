# LG 42LA640S-ZA Android Remote

Redmi 12 IR + LG NetCast 4.0 network remote.

## Features
- LG 42LA640S-ZA / LA64 family button layout
- LG NEC IR codes for standard remote buttons
- Automatic preference for LAN/UDAP when paired
- IR fallback when TV is not reachable on the network
- SSDP TV discovery
- Network mouse / touchpad: move, click, wheel
- Network text keyboard using NetCast TextEdited events
- Saved TV IP + pairing PIN
- GitHub Actions APK build

## Important
The TV is a 2013 NetCast TV. It does **not** use modern webOS SSAP/WebSocket control. This project uses the older LG UDAP/NetCast protocol on TCP 8080.

Network control requires the phone and TV to be on the same LAN/Wi-Fi. Internet access itself is not required. The first network connection displays a pairing PIN on the TV.

When the TV is off or the network path is unavailable, IR buttons can still work. A full QWERTY text keyboard is only possible through the network text-input protocol; a normal IR remote does not have a way to send arbitrary text directly.
