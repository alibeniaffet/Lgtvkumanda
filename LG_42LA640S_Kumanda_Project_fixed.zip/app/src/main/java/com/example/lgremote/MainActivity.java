package com.example.lgremote;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.hardware.ConsumerIrManager;
import android.net.wifi.WifiManager;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

/**
 * LG 42LA640S-ZA remote for NetCast 4.0.
 * Network mode uses LG UDAP/NetCast (HTTP on port 8080).
 * IR mode uses Android ConsumerIrManager and LG NEC 32-bit codes.
 */
public class MainActivity extends Activity {
    private ConsumerIrManager ir;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private EditText ipEdit, pairEdit, textEdit;
    private TextView status;
    private String tvIp = "";
    private boolean networkReady = false;
    private LGNetwork tv;
    private float downX, downY;
    private long downTime;
    private boolean mouseMoved;
    private Handler handler = new Handler(Looper.getMainLooper());

    // LG IR command bytes from LG documentation for the LA64 family.
    private static final Map<String,Integer> IR = new LinkedHashMap<>();
    static {
        putIR("POWER",0x08); putIR("ENERGY SAVING",0x95); putIR("AV MODE",0x30); putIR("INPUT",0x0B);
        putIR("TV/RAD",0x0F); putIR("LIST",0x4C); putIR("Q.VIEW",0x1A); putIR("VOL+",0x02); putIR("VOL-",0x03);
        putIR("FAV",0x1E); putIR("3D",0xDC); putIR("MUTE",0x09); putIR("CH+",0x00); putIR("CH-",0x01);
        putIR("SETTINGS",0x43); putIR("HOME",0x7C); putIR("SMART",0x7C); putIR("MY APPS",0x42); putIR("GUIDE",0xAB); putIR("Q.MENU",0x45); putIR("BACK",0x28); putIR("INFO",0xAA);
        putIR("EXIT",0x5B); putIR("OK",0x44); putIR("UP",0x40); putIR("DOWN",0x41); putIR("LEFT",0x07); putIR("RIGHT",0x06);
        putIR("RED",0x72); putIR("GREEN",0x71); putIR("YELLOW",0x63); putIR("BLUE",0x61);
        putIR("TEXT",0x20); putIR("T.OPT",0x21); putIR("SUBTITLE",0x39); putIR("REW",0x8F); putIR("PLAY",0xB0);
        putIR("PAUSE",0xBA); putIR("FF",0x8E); putIR("SIMPLINK",0x7E); putIR("RATIO",0x79); putIR("AD",0x91); putIR("DELETE",0x09); putIR("LIVE TV",0xB1); putIR("REC",0xBD); putIR("STOP",0xBA);
        putIR("PORTAL",0x0C); putIR("FREEZE",0xBA);
        for(int i=0;i<=9;i++) putIR("N"+i,0x10+i);
    }
    private static void putIR(String name,int cmd){ IR.put(name,cmd); }


    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE);
        android.content.SharedPreferences p=getSharedPreferences("lgremote",MODE_PRIVATE);
        tvIp=p.getString("ip","");
        buildUi(p);
    }

    private void buildUi(android.content.SharedPreferences p){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,12,12,24);
        TextView title=new TextView(this); title.setText("LG 42LA640S-ZA • Tam Kumanda"); title.setTextSize(21); title.setTextColor(Color.WHITE); title.setPadding(12,12,12,12); title.setBackgroundColor(Color.rgb(30,30,30)); root.addView(title);
        status=new TextView(this); status.setText("Hazır • IR: "+(hasIR()?"VAR":"YOK")+" • Ağ: bekleniyor"); status.setPadding(10,10,10,10); root.addView(status);

        LinearLayout conn=new LinearLayout(this); conn.setOrientation(LinearLayout.HORIZONTAL);
        ipEdit=new EditText(this); ipEdit.setHint("TV IP (ör. 192.168.1.20)"); ipEdit.setText(tvIp); ipEdit.setSingleLine(); conn.addView(ipEdit,new LinearLayout.LayoutParams(0,55,2));
        Button scan=button("TV Bul"); scan.setOnClickListener(v->discoverTV()); conn.addView(scan,new LinearLayout.LayoutParams(0,55,1));
        Button pair=button("Ağa Bağlan"); pair.setOnClickListener(v->showPairing()); conn.addView(pair,new LinearLayout.LayoutParams(0,55,1)); root.addView(conn);

        TextView note=new TextView(this); note.setText("Öncelik: TV aynı Wi‑Fi/LAN'daysa ağ. Ağ yoksa IR otomatik kullanılabilir. TV kapalıysa ağ açılamaz; POWER için IR kullanılır."); note.setPadding(8,6,8,12); root.addView(note);

        ScrollView scroll=new ScrollView(this); LinearLayout all=new LinearLayout(this); all.setOrientation(LinearLayout.VERTICAL);
        addSection(all,"ANA KUMANDA");
        addButtonGrid(all,new String[][]{{"POWER","INPUT","TV/RAD","AV MODE","ENERGY SAVING"},{"VOL-","MUTE","VOL+","CH-","CH+"},{"LIST","Q.VIEW","FAV","MARK","3D"},{"HOME","GUIDE","INFO","Q.MENU","EXIT"}});
        addSection(all,"YÖN / MENÜ");
        addButtonGrid(all,new String[][]{{"UP"},{"LEFT","OK","RIGHT"},{"DOWN"},{"BACK","SETTINGS","MY APPS","SMART"}});
        addSection(all,"SAYILAR");
        addButtonGrid(all,new String[][]{{"N1","N2","N3"},{"N4","N5","N6"},{"N7","N8","N9"},{"N0","DASH","FLASHBK"}});
        addSection(all,"RENK / TELETEXT / ALTYAZI");
        addButtonGrid(all,new String[][]{{"RED","GREEN","YELLOW","BLUE"},{"TEXT","T.OPT","SUBTITLE","AD"}});
        addSection(all,"MEDYA / TIME MACHINE");
        addButtonGrid(all,new String[][]{{"REW","PLAY","PAUSE","FF"},{"STOP","REC","RECORDING LIST","LIVE TV"},{"SKIP BACK","SKIP FORWARD","REPEAT","FREEZE"}});
        addSection(all,"DİĞER");
        addButtonGrid(all,new String[][]{{"RATIO","SIMPLINK","PORTAL","APP","3D L/R"},{"PAGE UP","PAGE DOWN","MARK","NETCAST"}});

        addSection(all,"🖱️ AĞ MOUSE / TOUCHPAD");
        TextView mouseInfo=new TextView(this); mouseInfo.setText("Parmağını alanda sürükle = imleç • kısa dokun = tık • çift dokun = çift tık • kaydırma için aşağıdaki tuşlar"); all.addView(mouseInfo);
        FrameLayout pad=new FrameLayout(this); pad.setBackgroundColor(Color.rgb(35,35,35)); pad.setMinimumHeight(360); pad.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN: downX=e.getX(); downY=e.getY(); downTime=System.currentTimeMillis(); mouseMoved=false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=e.getX()-downX, dy=e.getY()-downY;
                    if(Math.abs(dx)+Math.abs(dy)>2){ mouseMoved=true; networkMouseMove(dx*1.8f,dy*1.8f); downX=e.getX(); downY=e.getY(); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if(!mouseMoved && System.currentTimeMillis()-downTime<500) networkCommand("click",0);
                    return true;
            } return true;
        });
        TextView padLabel=new TextView(this); padLabel.setText("TOUCHPAD\n\nSürükle / Dokun"); padLabel.setTextColor(Color.LTGRAY); padLabel.setGravity(Gravity.CENTER); pad.addView(padLabel,new FrameLayout.LayoutParams(-1,-1)); all.addView(pad,new LinearLayout.LayoutParams(-1,360));
        LinearLayout wheels=new LinearLayout(this); Button up=button("▲ Kaydır"); up.setOnClickListener(v->networkCommand("wheelUp",0)); Button down=button("▼ Kaydır"); down.setOnClickListener(v->networkCommand("wheelDown",0)); wheels.addView(up,new LinearLayout.LayoutParams(0,60,1)); wheels.addView(down,new LinearLayout.LayoutParams(0,60,1)); all.addView(wheels);

        addSection(all,"⌨️ AĞ KLAVYESİ");
        textEdit=new EditText(this); textEdit.setHint("TV'deki yazı alanına metin yaz..."); textEdit.setSingleLine(false); all.addView(textEdit,new LinearLayout.LayoutParams(-1,120));
        Button send=button("Metni TV'ye Gönder"); send.setOnClickListener(v->sendText(false)); all.addView(send);
        LinearLayout kb=new LinearLayout(this); Button del=button("⌫ Sil"); del.setOnClickListener(v->sendDelete()); Button enter=button("ENTER"); enter.setOnClickListener(v->sendText(true)); kb.addView(del,new LinearLayout.LayoutParams(0,60,1)); kb.addView(enter,new LinearLayout.LayoutParams(0,60,1)); all.addView(kb);
        TextView keyboardNote=new TextView(this); keyboardNote.setText("Tam metin klavyesi NetCast ağ protokolünü kullanır. IR modunda TV'ye gerçek QWERTY metin gönderilemez; IR'de sayısal kumanda kullanılabilir."); keyboardNote.setPadding(8,8,8,16); all.addView(keyboardNote);

        scroll.addView(all); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    private void addSection(LinearLayout p,String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(17); t.setTextColor(Color.WHITE); t.setPadding(8,18,8,6); t.setBackgroundColor(Color.rgb(65,65,65)); p.addView(t); }
    private void addButtonGrid(LinearLayout parent,String[][] rows){
        for(String[] names:rows){ LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for(String n:names){ Button b=button(label(n)); b.setOnClickListener(v->press(n)); row.addView(b,new LinearLayout.LayoutParams(0,62,1)); }
            parent.addView(row);
        }
    }
    private String label(String n){ return n.replace("N","#").replace("PAGE ","PAGE "); }

    private void press(String name){
        Integer c=IR.get(name);
        if(networkReady){ networkKey(name); return; }
        if(c!=null){ sendIR(c); return; }
        Toast.makeText(this,"Bu tuş ağ modunda kullanılabilir: "+name,Toast.LENGTH_SHORT).show();
    }

    private boolean hasIR(){ return ir!=null && ir.hasIrEmitter(); }
    private void sendIR(int cmd){
        if(!hasIR()){ Toast.makeText(this,"IR vericisi bulunamadı.",Toast.LENGTH_SHORT).show(); return; }
        int d=(cmd&0xFF)|((cmd^0xFF)&0xFF)<<8;
        // LG NEC frame: 0x20DF + command + inverse(command), LSB first.
        int data=0x04FB0000 | (cmd<<8) | (cmd^0xFF);
        ArrayList<Integer> p=new ArrayList<>(); p.add(9000); p.add(4500);
        for(int i=0;i<32;i++){ p.add(560); p.add(((data>>>i)&1)==1?1690:560); } p.add(560);
        int[] a=new int[p.size()]; for(int i=0;i<a.length;i++)a[i]=p.get(i);
        ir.transmit(38000,a);
    }

    private void showPairing(){
        final String ip=ipEdit.getText().toString().trim();
        if(!ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")){ Toast.makeText(this,"Önce TV IP adresini seç/yaz.",Toast.LENGTH_SHORT).show(); return; }
        tvIp=ip; getSharedPreferences("lgremote",MODE_PRIVATE).edit().putString("ip",ip).apply();
        io.execute(()->{
            try{
                String r=LGNetwork.post(ip,"/udap/api/pairing",LGNetwork.xml("pairing",new String[][]{{"name","showKey"}}));
                runOnUiThread(()->pairDialog(ip));
            }catch(Exception e){ runOnUiThread(()->Toast.makeText(this,"TV'ye ulaşılamadı: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        });
    }

    private void pairDialog(String ip){
        final EditText code=new EditText(this); code.setHint("TV'de çıkan eşleştirme kodu"); code.setInputType(2); code.setSingleLine();
        new AlertDialog.Builder(this).setTitle("LG TV eşleştirme").setMessage("TV ekranında görünen PIN'i gir.").setView(code).setNegativeButton("İptal",null).setPositiveButton("Bağlan",(d,w)->{
            String key=code.getText().toString().trim();
            io.execute(()->{
                try{
                    LGNetwork.post(ip,"/udap/api/pairing",LGNetwork.xml("pairing",new String[][]{{"name","hello"},{"value",key},{"port","8080"}}));
                    getSharedPreferences("lgremote",MODE_PRIVATE).edit().putString("pairkey",key).putString("ip",ip).apply();
                    networkReady=true; tv=new LGNetwork(ip); runOnUiThread(()->status.setText("AĞ BAĞLI • "+ip+" • Mouse + klavye hazır"));
                }catch(Exception e){ runOnUiThread(()->Toast.makeText(this,"Eşleştirme başarısız: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
            });
        }).show();
    }

    private void discoverTV(){
        status.setText("TV aranıyor…");
        io.execute(()->{
            WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE); WifiManager.MulticastLock lock=null;
            try{
                if(wm!=null){ lock=wm.createMulticastLock("lgremote"); lock.setReferenceCounted(false); lock.acquire(); }
                DatagramSocket s=new DatagramSocket(); s.setSoTimeout(1800);
                String q="M-SEARCH * HTTP/1.1\\r\\nHOST: 239.255.255.250:1900\\r\\nMAN: \"ssdp:discover\"\\r\\nMX: 2\\r\\nST: urn:schemas-upnp-org:device:MediaRenderer:1\\r\\n\\r\\n";
                byte[] data=q.getBytes(StandardCharsets.UTF_8); DatagramPacket p=new DatagramPacket(data,data.length,InetAddress.getByName("239.255.255.250"),1900); s.send(p);
                byte[] buf=new byte[4096]; long end=System.currentTimeMillis()+2500;
                while(System.currentTimeMillis()<end){ try{ DatagramPacket r=new DatagramPacket(buf,buf.length); s.receive(r); String x=new String(r.getData(),0,r.getLength(),StandardCharsets.UTF_8); String loc=header(x,"location"); if(loc!=null){ Matcher m=Pattern.compile("https?://([^/:]+)(?::(\\d+))?",Pattern.CASE_INSENSITIVE).matcher(loc); if(m.find()){ String host=m.group(1); runOnUiThread(()->{ipEdit.setText(host); status.setText("LG TV bulundu: "+host+" • Ağa bağlanmak için butona bas");}); break; } } }catch(SocketTimeoutException ex){ break; } }
                s.close();
            }catch(Exception e){ runOnUiThread(()->status.setText("TV bulunamadı. IP'yi elle yazabilirsin.")); }
            finally{ if(lock!=null)lock.release(); }
        });
    }
    private String header(String s,String name){ for(String line:s.split("\\r?\\n")){ int i=line.indexOf(':'); if(i>0&&line.substring(0,i).trim().equalsIgnoreCase(name))return line.substring(i+1).trim(); } return null; }

    private void ensureNetwork(){ if(networkReady)return; String ip=ipEdit.getText().toString().trim(); String key=getSharedPreferences("lgremote",MODE_PRIVATE).getString("pairkey",""); if(ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")&&!key.isEmpty()){ networkReady=true; tv=new LGNetwork(ip); status.setText("AĞ HAZIR • "+ip); } }
    private void networkKey(String name){ ensureNetwork(); if(!networkReady){ Toast.makeText(this,"Önce Ağa Bağlan ile TV'yi eşleştir.",Toast.LENGTH_SHORT).show(); return;} Integer code=networkCode(name); if(code==null){ if(name.equals("SETTINGS"))code=21; else if(name.equals("SMART")||name.equals("NETCAST"))code=408; else if(name.equals("MY APPS"))code=417; else if(name.equals("MARK"))code=52; else if(name.equals("PAGE UP"))code=12; else if(name.equals("PAGE DOWN"))code=13; else if(name.equals("RECORDING LIST"))code=41; else if(name.equals("SKIP BACK"))code=39; else if(name.equals("SKIP FORWARD"))code=38; else if(name.equals("REPEAT"))code=42; else if(name.equals("FREEZE"))code=404; else if(name.equals("DASH"))code=402; else if(name.equals("FLASHBK"))code=403; else if(name.equals("APP"))code=417; else if(name.equals("3D L/R"))code=401; }
        if(code!=null) finalSendKey(code);
    }
    private Integer networkCode(String n){
        switch(n){case"POWER":return 1;case"UP":return 12;case"DOWN":return 13;case"LEFT":return 14;case"RIGHT":return 15;case"OK":return 20;case"HOME":return 21;case"BACK":return 23;case"VOL+":return 24;case"VOL-":return 25;case"MUTE":return 26;case"CH+":return 27;case"CH-":return 28;case"RED":return 31;case"GREEN":return 30;case"YELLOW":return 32;case"BLUE":return 29;case"PLAY":return 33;case"PAUSE":return 34;case"STOP":return 35;case"FF":return 36;case"REW":return 37;case"SKIP FORWARD":return 38;case"SKIP BACK":return 39;case"REC":return 40;case"RECORDING LIST":return 41;case"REPEAT":return 42;case"LIVE TV":return 43;case"GUIDE":return 44;case"INFO":return 45;case"RATIO":return 46;case"INPUT":return 47;case"SUBTITLE":return 49;case"LIST":return 50;case"TEXT":return 51;case"MARK":return 52;case"3D":return 400;case"3D L/R":return 401;case"DASH":return 402;case"FLASHBK":return 403;case"FAV":return 404;case"Q.MENU":return 405;case"T.OPT":return 406;case"AD":return 407;case"ENERGY SAVING":return 409;case"AV MODE":return 410;case"SIMPLINK":return 411;case"EXIT":return 412;case"PAGE UP":return 414;case"PAGE DOWN":return 415;case"APP":return 417;case"TV/RAD":return 408;case"N0":return 2;case"N1":return 3;case"N2":return 4;case"N3":return 5;case"N4":return 6;case"N5":return 7;case"N6":return 8;case"N7":return 9;case"N8":return 10;case"N9":return 11;} return null;
    }
    private void finalSendKey(int code){ io.execute(()->{try{ if(tv==null)tv=new LGNetwork(ipEdit.getText().toString().trim()); tv.key(code);}catch(Exception e){ networkReady=false; runOnUiThread(()->status.setText("Ağ bağlantısı koptu • IR modu")); String irName=networkNameForCode(code); Integer irCmd=IR.get(irName); if(irCmd!=null) sendIR(irCmd); }}); }
    private String networkNameForCode(int code){ switch(code){case 1:return "POWER";case 2:return "N0";case 3:return "N1";case 4:return "N2";case 5:return "N3";case 6:return "N4";case 7:return "N5";case 8:return "N6";case 9:return "N7";case 10:return "N8";case 11:return "N9";case 12:return "UP";case 13:return "DOWN";case 14:return "LEFT";case 15:return "RIGHT";case 20:return "OK";case 21:return "HOME";case 23:return "BACK";case 24:return "VOL+";case 25:return "VOL-";case 26:return "MUTE";case 27:return "CH+";case 28:return "CH-";case 29:return "BLUE";case 30:return "GREEN";case 31:return "RED";case 32:return "YELLOW";case 33:return "PLAY";case 34:return "PAUSE";case 35:return "STOP";case 36:return "FF";case 37:return "REW";case 40:return "REC";case 43:return "LIVE TV";case 44:return "GUIDE";case 45:return "INFO";case 46:return "RATIO";case 47:return "INPUT";case 49:return "SUBTITLE";case 50:return "LIST";case 51:return "TEXT";case 52:return "MARK";case 400:return "3D";case 401:return "3D L/R";case 402:return "DASH";case 403:return "FLASHBK";case 404:return "FAV";case 405:return "Q.MENU";case 406:return "T.OPT";case 407:return "AD";case 409:return "ENERGY SAVING";case 410:return "AV MODE";case 411:return "SIMPLINK";case 412:return "EXIT";case 417:return "MY APPS";} return null; }
    private void networkCommand(String type,int v){ ensureNetwork(); if(!networkReady){Toast.makeText(this,"Mouse yalnızca ağ modunda çalışır.",Toast.LENGTH_SHORT).show();return;} io.execute(()->{try{ if(tv==null)tv=new LGNetwork(ipEdit.getText().toString().trim()); if(type.equals("click"))tv.click(); else if(type.equals("wheelUp"))tv.wheel("up"); else if(type.equals("wheelDown"))tv.wheel("down"); }catch(Exception e){networkReady=false;}}); }
    private void networkMouseMove(float dx,float dy){ ensureNetwork(); if(!networkReady)return; int x=Math.max(-80,Math.min(80,Math.round(dx))), y=Math.max(-80,Math.min(80,Math.round(dy))); if(x==0&&y==0)return; io.execute(()->{try{ if(tv==null)tv=new LGNetwork(ipEdit.getText().toString().trim()); tv.cursorVisible(true); tv.move(x,y);}catch(Exception e){networkReady=false;}}); }
    private void sendText(boolean enter){ ensureNetwork(); if(!networkReady){Toast.makeText(this,"Klavye için TV ile ağ bağlantısı gerekir.",Toast.LENGTH_SHORT).show();return;} String s=textEdit.getText().toString(); io.execute(()->{try{ if(tv==null)tv=new LGNetwork(ipEdit.getText().toString().trim()); tv.textEdited(enter?"EditEnd":"Editing",s); if(enter)tv.key(31);}catch(Exception e){}}); }
    private void sendDelete(){ ensureNetwork(); if(!networkReady)return; String s=textEdit.getText().toString(); if(s.length()>0){ textEdit.setText(s.substring(0,s.length()-1)); textEdit.setSelection(textEdit.length()); } sendText(false); }

    @Override protected void onDestroy(){ io.shutdownNow(); super.onDestroy(); }

    static class LGNetwork {
        final String ip; final int port=8080;
        LGNetwork(String ip){this.ip=ip;}
        static String xml(String api,String[][] p){ StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?><envelope><api type=\"").append(api).append("\">"); for(String[] a:p)b.append('<').append(a[0]).append('>').append(escape(a[1])).append("</").append(a[0]).append('>'); return b.append("</api></envelope>").toString(); }
        void key(int code)throws Exception{ post(ip,"/udap/api/command",xml("command",new String[][]{{"name","HandleKeyInput"},{"value",String.valueOf(code)}})); }
        void move(int x,int y)throws Exception{ post(ip,"/udap/api/command",xml("command",new String[][]{{"name","HandleTouchMove"},{"x",String.valueOf(x)},{"y",String.valueOf(y)}})); }
        void click()throws Exception{ post(ip,"/udap/api/command",xml("command",new String[][]{{"name","HandleTouchClick"}})); }
        void wheel(String d)throws Exception{ post(ip,"/udap/api/command",xml("command",new String[][]{{"name","HandleTouchWheel"},{"value",d}})); }
        void cursorVisible(boolean on)throws Exception{ post(ip,"/udap/api/event",xml("event",new String[][]{{"name","CursorVisible"},{"value",on?"true":"false"},{"mode","auto"}})); }
        void textEdited(String state,String value)throws Exception{ post(ip,"/udap/api/event",xml("event",new String[][]{{"name","TextEdited"},{"state",state},{"value",value}})); }
        static String post(String host,String path,String body)throws Exception{ URL u=new URL("http://"+host+":8080"+path); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(1800);c.setReadTimeout(2500);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","text/xml; charset=utf-8");c.setRequestProperty("Connection","Keep-Alive"); try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));} int code=c.getResponseCode(); if(code<200||code>=300)throw new IOException("HTTP "+code); InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8"); }
        static String escape(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    }
}
